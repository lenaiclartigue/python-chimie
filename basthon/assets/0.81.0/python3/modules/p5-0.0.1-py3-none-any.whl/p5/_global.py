"""
A wrapper for p5.js global mode.
This is not intended to be used directly but from
 p5 with from p5 import * .

This is a bit tricky since we have to:
 + get all members names (functions + attributes)
 + exposes them to global scope for import *
 + wrap function that gets a pointer to global instance
 + update attributes (int, str, float, ...) before each call to setup/draw.
This last step is a bit dirty since we modify them (carefully)
directly in the global namespace.
"""

from . import _core  # /!\ do not remove! this ensure p5.js is loaded
from . import _events
from ._nsmanager import NSManager
import js
from pyodide.ffi import JsProxy, to_js as _to_js

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


def isJsProxy(obj):
    return isinstance(obj, JsProxy)


def isJsFunc(obj):
    return isJsProxy(obj) and callable(obj)


__all__ = ["run", "show", "stop", "load_library", "update_variables"]


def __dir__():
    return __all__


# the global p5.js instance
_instance = None
# the global P5SketchGlobal instance
_wrapped_instance = None
# functions that callback global instance
_wrapped_functions = None
# ignored p5.js functions (avoid conflict with builtins and user entry points)
_ignored_p5_functions = _events.ENTRY_POINTS + (
    "abs",
    "float",
    "hex",
    "int",
    "max",
    "min",
    "pow",
    "print",
    "round",
    "str",
)
_custom_p5_functions = ("filter", "map", "set")


def _p5_members():
    """
    Dynamically recover functions/attributes of a p5 instance.
    """
    # using detached node to ensure canvas is hidden
    node = js.document.createElement("div")
    dummy = js.p5.new(lambda _: None, node)
    members = {
        a: getattr(dummy, a)
        for a in dir(dummy)
        if not a.startswith("_") and a not in _ignored_p5_functions
    }
    dummy.remove()
    return members


# splitting members in functions/attributes
_members = _p5_members()
_functions = set()
_attributes = set()
for k, v in _members.items():
    if isJsProxy(v):
        if isJsFunc(v):
            _functions.add(k)
        else:
            # JsProxy (canvas, drawingContext, pixels, touches) are ignored
            pass
    else:
        _attributes.add(k)


# import * imports functions and attributes
__all__ += _functions
__all__ += _attributes

# we check for name collision
if len(__all__) != len(set(__all__)):
    duplicate = next(x for x in __all__ if __all__.count(x) > 1)
    raise NameError(f"Internal collision name in p5 for {duplicate}.")


# types implicitly converted by Pyodide when calling JS (no to_js needed)
_implicit_types = (int, float, str, bool, type(None))


class FunctionWrapper(object):
    """
    A function wrapper for p5.js golbal instance functions.
    This is performance critical (called thousands of times per frame).
    """

    def __init__(self, func_name):
        self._func_name = func_name
        # method of the global instance (cached while instance is the same)
        self._instance = None
        self._method = None

    def __call__(self, *args):
        if self._instance is not _instance:
            self._instance = _instance
            self._method = getattr(_instance, self._func_name)
        for a in args:
            if type(a) not in _implicit_types:
                args = tuple(_to_js(a) for a in args)
                break
        # calling corresponding function from global instance
        return self._method(*args)


# wrapping functions
_wrapped_functions = {f: FunctionWrapper(f) for f in _functions}


# custom wrappers
def _custom_filter(*args):
    if len(args) > 1 and (args[0] is None or callable(args[0])):
        return filter(*args)
    else:
        return _instance.filter(*args)


_wrapped_functions["filter"] = _custom_filter


def _custom_map(*args):
    if len(args) > 1 and callable(args[0]):
        return map(*args)
    else:
        return _instance.map(*args)


_wrapped_functions["map"] = _custom_map


def _custom_set(*args):
    if len(args) < 2:
        return set(*args)
    else:
        return _instance.set(*args)


_wrapped_functions["set"] = _custom_set


def __getattr__(name):
    """
    Wrapping member access:
      + attributes access is delegate to global instance ;
      + function access is delegate to _wrapped_functions.
    """
    if name in _attributes:
        return getattr(_instance, name) if _instance is not None else None
    elif name in _wrapped_functions:
        return _wrapped_functions[name]
    else:
        try:
            return globals()[name]
        except KeyError:
            raise AttributeError(name)


nsmanager = NSManager(_attributes)


def _update_global_attributes(func):
    """
    Updating attributes in the global scope of func with sketch ones.
    """
    nsmanager.update_attributes(_instance, func.__globals__)


def _reset_instance(sketch):
    """
    Reset global instance (stoping current one).
    """
    global _instance
    if _instance is not None:
        # stoping and removing entry points seems OK
        # but if strange things appends, it could be safe
        # to remove it with _instance.remove()
        _instance.noLoop()
        _events.detach(_instance)
        _core.close_display(_instance)
    _instance = sketch


class P5SketchGlobal(_core.P5SketchBase):
    """
    P5 global object derived from core P5SketchBase, see _core.py.
    """

    def _init_sketch(self, sketch):
        _reset_instance(sketch)

    def _wrap(self, sketch, entry_points):
        def wrap(f):
            """update globals attributes of f before calling it."""
            return _events.wrap(f, before=lambda: _update_global_attributes(f))

        return {name: wrap(f) for name, f in entry_points.items()}


class _HandlerTracker(object):
    """
    Detect stale event handlers in the global namespace.

    The namespace persists between runs, so a handler removed from the
    user code is still there (as the very same object). A handler
    recovered from the namespace is considered stale if it was already
    seen by a previous run, unless the same sketch (same setup and
    draw) is relaunched with this handler.
    """

    def __init__(self):
        # handlers seen in the namespace by previous runs
        self._seen = {}
        # (setup, draw, handlers) of the last run
        self._last = None

    def is_stale(self, name, func, setup, draw):
        if self._seen.get(name) is not func:
            return False  # new or redefined
        if self._last is None:
            return True
        last_setup, last_draw, last_handlers = self._last
        same_sketch = last_setup is setup and last_draw is draw
        return not (same_sketch and last_handlers.get(name) is func)

    def see(self, name, func):
        self._seen[name] = func

    def ran(self, setup, draw, handlers):
        self._last = (setup, draw, dict(handlers))


_handler_tracker = _HandlerTracker()


def run(setup=None, draw=None, preload=None, **handlers):
    """
    Run a new sketch using run(setup, draw) where setup and draw
    are standard p5.js functions.
    If a function is omited, we try to recover it from global namespace.

    Event handlers (mousePressed, keyPressed, ...) are recovered from
    global namespace or can be passed as keyword arguments
    (e.g. run(mousePressed=on_click)). Passing None disables one.
    """
    global _wrapped_instance

    # trying to recover setup and draw from global namespace
    if setup is None:
        setup = nsmanager.get_from_global_ns("setup")
    if draw is None:
        draw = nsmanager.get_from_global_ns("draw")
    # preload is not recovered from global namespace
    # otherwise next sketch will get previous preload

    # trying to recover event handlers from global namespace
    # (stale ones, i.e. removed from user code, are ignored)
    _events.check_names(handlers)
    from_ns = {}
    for name in _events.EVENT_HANDLERS:
        if name not in handlers:
            func = nsmanager.get_from_global_ns(name)
            if callable(func):
                from_ns[name] = func
                if not _handler_tracker.is_stale(name, func, setup, draw):
                    handlers[name] = func

    _wrapped_instance = P5SketchGlobal(setup, draw, preload, handlers).run()

    for name, func in from_ns.items():
        _handler_tracker.see(name, func)
    _handler_tracker.ran(setup, draw, handlers)


show = run


def stop():
    """
    Stopping global p5 instance.
    """
    return _wrapped_instance.stop()


def load_library(url):
    """Dynamically load a (p5) js library."""
    return _core.load_library(url)


def update_variables():
    """
    Force p5 variable update. E.g. this can be usefull after createCanvas
    to get width and height updated values.
    """
    nsmanager.update_attributes(_instance)
