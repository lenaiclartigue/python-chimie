"""
Core part of p5 wrapper. p5.js loading is done here.

In legacy mode, p5.js runs in the main thread and the sketch canvas
is directly displayed. In isolated mode (worker), p5.js runs on top
of a DOM emulation and the sketch is displayed in a kernel iframe
(see worker.js and iframe.html).
"""

from importlib.resources import files as _files
import js
from basthon import kernel
from pyodide.ffi import to_js as _to_js
from . import _events

__author__ = "Romain Casati"
__license__ = "GNU GPL v3"
__email__ = "romain.casati@basthon.fr"


__all__ = ["P5SketchBase", "load_library", "close_display"]


def __dir__():
    return __all__


_legacy = js.basthon.isLegacy()


def _read(filename):
    with (_files("p5") / filename).open() as f:
        return f.read()


if not _legacy:
    if not hasattr(js, "OffscreenCanvas"):
        raise ImportError("p5 module requires OffscreenCanvas support in browser.")
    _iframe_html = _read("bundle/iframe.html")

# p5.js patches and, in isolated mode, DOM emulation (before p5.js)
if not hasattr(js, "basthonP5"):
    js.eval(_read("bundle/worker.js"))

# loading p5.js
if not hasattr(js, "p5"):
    js.eval(_read("p5.min.js"))
    js.basthonP5.patch(js.p5)


def close_display(sketch):
    """
    Stop displaying a sketch (the last frame remains).
    Only useful in isolated mode.
    """
    if not _legacy:
        js.basthonP5.close(sketch)


class P5SketchBase(object):
    """
    P5 instance object that you can run and stop. Most of the time,
    this object is not build manualy but used as the return of p5.run.
    """

    def __init__(self, setup, draw, preload=None, handlers=None):
        if setup is None:
            raise ValueError("P5: setup function not set!")
        if draw is None:
            raise ValueError("P5: draw function not set!")
        handlers = handlers or {}
        _events.check_names(handlers)
        entry_points = {"preload": preload, "setup": setup, "draw": draw}
        entry_points.update(handlers)
        # user functions (not wrapped) by entry point name
        self._entry_points = {k: f for k, f in entry_points.items() if f is not None}
        # wrapped entry points (set when p5.js builds the sketch)
        self._wrapped = None
        self._node = None
        self._sketch = None

    def _init_sketch(self, sketch):
        """Called first when p5.js builds the sketch."""
        pass

    def _wrap(self, sketch, entry_points):
        """Wrap user entry points to be called back by p5.js."""
        raise NotImplementedError

    def _builder(self, entry_points):
        """JS function to create new P5 instance."""

        def func(sketch):
            self._init_sketch(sketch)
            self._wrapped = self._wrap(sketch, entry_points)
            _events.attach(sketch, self._wrapped)

        return func

    def run(self):
        """
        Start the P5 sketch.
        """
        if self._sketch is not None:
            # resuming: event handlers were detached by stop
            _events.attach(self._sketch, self._wrapped)
            self._sketch.loop()
            return self

        build_func = self._builder(self._entry_points)

        if not _legacy:
            # displaying in a kernel iframe
            node = js.basthonP5.createRoot()
            self._sketch = js.p5.new(build_func, node)
            port = js.basthon.displayKernelIFrame(_iframe_html)
            js.basthonP5.connect(self._sketch, port)
            self._node = node
            return self

        # new node that will contains canvas
        node = js.document.createElement("div")
        node.style.width = "100%"
        node.style.textAlign = "center"

        # main p5 call: create canvas and start drawing
        self._sketch = js.p5.new(build_func, node)

        # fix: in 3D, a blank canvas is added before... remove it
        while len(node.children) > 1:
            node.removeChild(node.children[0])

        # by default, node is hidden
        for n in node.children:
            n.style.visibility = "visible"

        # sending node to Basthon for rendering
        js.basthon.display(node)
        self._node = node
        return self

    def stop(self):
        """
        Stopping call to draw and event handlers.
        """
        if self._sketch is not None:
            self._sketch.noLoop()
            _events.detach(self._sketch, _events.EVENT_HANDLERS)

    def delete(self):
        """
        Properly delete the underlying canvas.
        """
        if self._sketch is not None:
            close_display(self._sketch)
            self._sketch.remove()
        if self._node is not None:
            if not _legacy:
                js.basthonP5.removeRoot(self._node)
            elif self._node.parentNode is not None:
                self._node.parentNode.removeChild(self._node)


def load_library(url):
    """Dynamically load a (p5) js library."""
    return js.Basthon.loadScript(url)
